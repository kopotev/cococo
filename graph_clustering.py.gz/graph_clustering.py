#!/usr/bin/python2
# coding: utf-8

from igraph import *
import gensim, logging
import codecs, sys
import csv
from itertools import combinations
from unidecode import unidecode
from gensim import matutils
import numpy as np

logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)

model = sys.argv[1]

if len(sys.argv) > 2:
    plottingdir = sys.argv[2]
    translations = sys.argv[3]
    trans = {}
    for line in codecs.open(translations, 'r', 'utf-8').readlines():
	res = line.strip().split('\t')
	(rus, en) = res
	en = en.strip().split()
	if len(en) > 1:
	    eng = en[1]
	else:
	    eng = en[0]
	if eng.strip() == 'voice' and not u'голос' in rus:
	    eng = en[2]
	if eng.strip().endswith(','):
	    eng = eng.strip()[:-1]
	trans[rus.strip()] = eng
else:
    plottingdir = False

if model.endswith('.vec.gz'):
    model = gensim.models.Word2Vec.load_word2vec_format(model, binary=False)
elif model.endswith('.bin.gz'):
    model = gensim.models.Word2Vec.load_word2vec_format(model, binary=True)
else:
    model = gensim.models.Word2Vec.load(model)

model.init_sims(replace=True)

oov = set()
associates = False

oov = set()

data = {}

for line in sys.stdin:
    if line.startswith('headword'):
        continue
    res = line.decode('utf-8').strip().split('\t')
    (headword, token, lemma, english, dice, ppmi, label, cluster) = res
    if not headword in data:
        data[headword] = {}
    if lemma in model:
        data[headword][lemma] = {}
        data[headword][lemma]['vector'] = model[lemma]
        #data[headword][lemma]['vector'] = np.add(model[lemma], model[headword])
        #data[headword][lemma]['vector'] = np.multiply(model[lemma], model[headword])
        data[headword][lemma]['frequency'] = model.wv.vocab[lemma].count
        data[headword][lemma]['headword'] = headword
        data[headword][lemma]['token'] = token
        data[headword][lemma]['lemma'] = lemma
        data[headword][lemma]['english'] = english
        data[headword][lemma]['cluster'] = cluster
        data[headword][lemma]['label'] = label
        data[headword][lemma]['sim'] = model.similarity(lemma, headword)
        #data[headword][lemma]['syn_sim'] = 1 - cosine(model.syn1neg[model.wv.vocab[headword].index], model.syn1neg[model.wv.vocab[lemma].index])
        data[headword][lemma]['dice'] = float(dice)
        data[headword][lemma]['ppmi'] = float(ppmi)
    else:
        oov.add(lemma)
        print >> sys.stderr, lemma, 'not found'

print '\t'.join(['headword', 'token', 'lemma', 'english', 'dice', 'ppmi',
                            'label', 'cluster', 'predicted_cluster'])

for headword in data:
    print >> sys.stderr, headword
    words = set(data[headword].keys())
    sims= []
    #for collocate in data[headword]:
    #    res = [data[headword][collocate]['headword'], data[headword][collocate]['token'], data[headword][collocate]['lemma'], data[headword][collocate]['english'],
    #    data[headword][collocate]['dice'], data[headword][collocate]['ppmi'], data[headword][collocate]['label'], data[headword][collocate]['cluster']]

    #    collocates[lemma] = [el.encode('utf-8') for el in res]
    #    words.add(lemma)
    #print >> sys.stderr, 'Adding vertexes...'

    g = Graph(len(words))
    g.vs["name"] = [word for word in words]

    for vertex in g.vs:
        vertex["shape"] = "circle"

    g.add_vertex(name=headword, shape="triangle")
    vertices = g.vs
    #print(len(vertices))

    if associates:
        print >> sys.stderr, 'Adding semantic associates for collocates'
        for vertex in vertices:
            if vertex["name"] not in words and vertex["name"] != headword:
                break
            if vertex["name"] in model:
                #print(vertex["name"])
                neighbors = [i[0] for i in model.most_similar(positive=[vertex["name"]], topn=10) if i[1] > sim_threshold]
                #print(neighbors)
                for neighbor in neighbors:
                    if not neighbor in words and not neighbor in g.vs["name"]:
                        g.add_vertex(name=neighbor, shape="square")
                        #print >> sys.stderr, 'Added from model:', neighbor

    #print >> sys.stderr, 'Drawing edges in the graph...'

    edge_counter = 0
    added_edges = []

    for pair in combinations(g.vs, 2):
        vertex = pair[0]
        vertex2 = pair[1]
        similarity = model.similarity(vertex["name"], vertex2["name"])
        sims.append(similarity)
    
    #sim_threshold = np.average(sims) - (np.std(sims)*len(g.vs))/150.0
    sim_threshold = np.average(sims) - len(g.vs)/1500.0

    for pair in combinations(g.vs, 2):
        vertex = pair[0]
        vertex2 = pair[1]
        if vertex2["name"] in model and vertex["name"] in model:
            if True:
            #if vertex2["name"] in neighbors[vertex["name"]] or vertex["name"] in neighbors[vertex2["name"]]:
                if not (vertex2.index, vertex.index) in added_edges:
                    similarity = model.similarity(vertex["name"], vertex2["name"])
                    if similarity < sim_threshold:
                        continue
                    g.add_edge(vertex["name"], vertex2["name"], weight=similarity)
                    g.es[edge_counter]["cos_sim"] = similarity
                    edge_counter += 1
                    added_edges.append((vertex.index, vertex2.index))

    #g.vs["label"] = [name.encode('utf-8').split('_')[0] for name in g.vs["name"]]
    if plottingdir:
        g.vs["label"] = [trans[name].encode('utf-8') for name in g.vs["name"]]

    layout = g.layout("fr")
    
    #print >> sys.stderr, 'Extracting clusters...'
    try:
	clusters = g.community_spinglass(weights="cos_sim", spins=20, gamma=1.08)
    except:
	print >> sys.stderr, 'The graph is unconnected; falling back to Infomap'
	clusters = g.community_infomap(edge_weights="cos_sim", trials=15)
    membership = clusters.membership

    #print >> sys.stderr, '\t', np.max(sims), '\t', np.min(sims), '\t', np.average(sims), '\t', np.std(sims), sim_threshold, len(g.vs)
    
    def limit(y):
	if y < 0.3:
	    return 0.0
	else:
	    return y/3.0

    if plottingdir:
        visual_style = {}
        visual_style["layout"] = layout
        visual_style["vertex_label_size"] = 15
        visual_style["vertex_size"] = 9
        visual_style["edge_width"] = [limit(x) for x in g.es['cos_sim']]
        en_headword = unidecode(headword)
        plot(clusters, os.path.join(plottingdir, en_headword.replace('_NOUN','.pdf')), **visual_style)

    for name, member in zip(g.vs["name"], membership):
        if name not in words:
            continue
        predicted = str(member)
        row = [data[headword][name]['headword'], data[headword][name]['token'], data[headword][name]['lemma'],
              data[headword][name]['english'], str(data[headword][name]['dice']),
              str(data[headword][name]['ppmi']), data[headword][name]['label'], data[headword][name]['cluster'], predicted]

        print '\t'.join(row).encode('utf-8')

