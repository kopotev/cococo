#!/usr/bin/python2
# coding: utf-8

import sys, gensim, logging, codecs, os
import numpy as np
from sklearn.cluster import AffinityPropagation, SpectralClustering
from unidecode import unidecode
import multiprocessing

from tsne import tsne
import matplotlib.pyplot as plt
from itertools import cycle
from matplotlib import font_manager
font = font_manager.FontProperties(fname='DroidSans.ttf')

cores = multiprocessing.cpu_count()-1

logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)

modelfile = sys.argv[1]

if len(sys.argv) > 2:
    plotting = sys.argv[2]
    translations = sys.argv[3]
    trans = {}
    for line in codecs.open(translations, 'r', 'utf-8').readlines():
        res = line.strip().split('\t')
        (rus, en) = res
        en = en.strip().split()
        if len(en) > 1:
            eng = en[1]
        else:
            eng = en[0]
        if eng.strip() == 'palm' and not u'ладонь' in rus:
            eng = en[2]
        if eng.strip().endswith(','):
            eng = eng.strip()[:-1]
        trans[rus.strip()] = eng
else:
    plotting = False


def visual(words, matrix, fname, n, labels, indices, headword):
    words = [trans[w] for w in words]
    headword = trans[headword]
    perplexity = 5.0
    dimensionality = matrix.shape[1]
    Y = tsne(matrix, 2, dimensionality, perplexity)
    plt.scatter(Y[:, 0], Y[:, 1], 20, marker='.')
    headwords = set()
    colors = cycle('bgrcmy')
    for k, col in zip(range(n), colors):
        class_members = labels == k
        cluster_center = Y[indices[k]]
        plt.plot(Y[class_members, 0], Y[class_members, 1], col + '.')
        plt.plot(cluster_center[0], cluster_center[1], 'o', markerfacecolor=col, markeredgecolor='k', markersize=10)
        plt.annotate(words[indices[k]].split('_')[0], xy=(cluster_center[0]-4, cluster_center[1]), size=16, fontproperties=font)
        headwords.add(words[indices[k]])
        for x in Y[class_members]:
            plt.plot([cluster_center[0], x[0]], [cluster_center[1], x[1]], col)
    for label, x, y in zip(words, Y[:, 0], Y[:, 1]):
        if not label in headwords:
            plt.annotate(label.split('_')[0], xy=(x-4, y), size=12, fontproperties=font)
    plt.title(headword.split('_')[0]+' (estimated number of clusters: %d)' % n, fontproperties=font)
    plt.savefig(fname, dpi=300, bbox_inches='tight')
    plt.close()


if modelfile.endswith('.vec.gz'):
    model = gensim.models.Word2Vec.load_word2vec_format(modelfile, binary=False)
elif modelfile.endswith('.bin.gz'):
    model = gensim.models.Word2Vec.load_word2vec_format(modelfile, binary=True)
else:
    model = gensim.models.Word2Vec.load(modelfile)
model.init_sims(replace=True)

freq_bias = -1.8 # shift frequency before using it in preferences of affinity propagation

oov = set()

print '\t'.join(['headword', 'token', 'lemma', 'english', 'dice', 'ppmi',
                            'label', 'cluster', 'predicted_cluster'])
data = {}

for line in sys.stdin:
    if line.startswith('headword'):
	continue
    res = line.decode('utf-8').strip().split('\t')
    (headword, token, lemma, english, dice, ppmi, label, cluster) = res
    if not headword in data:
	data[headword] = {}
    entity = lemma
    if entity in model:
        data[headword][entity] = {}
        data[headword][entity]['vector'] = model[entity]
        data[headword][entity]['frequency'] = model.wv.vocab[entity].count
        data[headword][entity]['headword'] = headword
        data[headword][entity]['token'] = token
        data[headword][entity]['lemma'] = lemma
        data[headword][entity]['english'] = english
        data[headword][entity]['cluster'] = cluster
        data[headword][entity]['label'] = label
        data[headword][entity]['sim'] = model.similarity(entity, headword)
        data[headword][entity]['dice'] = float(dice)
        data[headword][entity]['ppmi'] = float(ppmi)
    else:
        oov.add(entity)
        print >> sys.stderr, entity, 'not found'

for headword in data:
    data[headword][headword] = {}
    data[headword][headword]['vector'] = model[headword]
    data[headword][headword]['frequency'] = model.wv.vocab[headword].count

    lw = len(data[headword])
    matrix = np.zeros((lw, model.vector_size))
    frequencies = np.zeros(lw)
    realclusters = np.zeros(lw)
    for i in xrange(lw):
	word = data[headword].keys()[i]
	if word != headword:
	    realclusters[i] = data[headword][word]['cluster']
	matrix[i,:] = data[headword][word]['vector']
	norm_freq = np.log10(data[headword][word]['frequency'])/10.0
	frequencies[i] = freq_bias - norm_freq

    af = AffinityPropagation(preference=frequencies).fit(matrix)
    cluster_centers_indices = af.cluster_centers_indices_
    labels = af.labels_
    n_clusters_ = len(cluster_centers_indices)
    
    if plotting:
	en_headword = unidecode(headword)
	visual(data[headword].keys(), matrix, os.path.join(plotting, headword+'.pdf'), n_clusters_, labels, cluster_centers_indices, headword)

    #real_clustering = SpectralClustering(n_clusters=n_clusters_, n_jobs=cores).fit(matrix)
    #labels = real_clustering.labels_

    for k in range(n_clusters_):
	class_members = labels == k
	for member, word in zip(class_members, data[headword].keys()):
	    if word == headword:
		continue
	    if member:
		predicted = str(k)
		row = [data[headword][word]['headword'], data[headword][word]['token'], data[headword][word]['lemma'],
                data[headword][word]['english'], str(data[headword][word]['dice']),
                str(data[headword][word]['ppmi']), data[headword][word]['label'], data[headword][word]['cluster'], predicted]

		print '\t'.join(row).encode('utf-8')
